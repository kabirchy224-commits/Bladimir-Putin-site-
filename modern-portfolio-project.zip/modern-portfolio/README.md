# Modern Developer Portfolio

A responsive personal portfolio website built with plain HTML, CSS, and JavaScript. No build tools or package installation required.

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a browser.

Optional: use the **Live Server** extension in VS Code for local preview.

## Customize before publishing
Search the project files for these demo values and replace them:
- `Alex Morgan` / `alex.dev` — your name and brand
- `hello@example.com` — your email address
- `yourusername` — your GitHub and LinkedIn usernames
- Project names, descriptions, skills, experience, and statistics — replace with your real work
- Update the page title and meta description in `index.html`

Do not claim demo projects, experience, or skills as real achievements. Replace them with work you have actually completed, or label them clearly as practice/demo projects.

## Publish with GitHub Pages
1. Create a **Public** repository on GitHub, for example `my-portfolio`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site. The URL will appear in the Pages section.

## Files
- `index.html` — page content and structure
- `style.css` — responsive styling and visual design
- `script.js` — mobile menu, theme toggle, and footer year
